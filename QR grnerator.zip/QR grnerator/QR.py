import qrcode as qr
img= qr.make("https://www.youtube.com/@tseries")
img.save("T_series_youtube.png")